<?php include 'navbar.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/navbar.css">
    <link rel="stylesheet" type="text/css" href="css/modal.css">

    <title>Sanction</title>
</head>
<body>
    <h1>Sanction Page</h1>
    <p>This is the sanction page where you can view sanctions.</p>
</body>
</html>
